<?php

namespace App\Charts;

use ConsoleTVs\Charts\Classes\Fusioncharts\Chart;

class waterTank extends Chart
{
    /**
     * Initializes the chart.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();

    }
}
