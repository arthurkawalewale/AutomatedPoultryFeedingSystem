<?php

namespace App\Http\Livewire;

use App\Charts\WaterLevelChart;
use App\Models\WaterReading;
use App\Support\Livewire\ChartComponent;
use App\Support\Livewire\ChartComponentData;
use Illuminate\Support\Collection;
use Livewire\Component;

class WaterLevelDataSets extends ChartComponent
{
    /*public function render()
    {
        return view('livewire.water-level-data-sets');
    }*


    /**
     * @return string
     */
    protected function view(): string
    {
        return 'livewire.water-level-data-sets';
    }

    /**
     * @return string
     */
    protected function chartClass(): string
    {
        return WaterLevelChart::class;
    }

    /**
     * @return \App\Support\Livewire\ChartComponentData
     */
    protected function chartData(): ChartComponentData
    {
        $water_level_data_sets = WaterReading::query()
            ->select(['id', 'created_at', 'reading'])
            ->where('created_at', '>=', Carbon::now()->subDay())
            ->where('created_at', '<=', Carbon::now())
            ->get();

        $labels = $water_level_data_sets->map(function(WaterReading $water_level_data_sets, $key) {
            return $water_level_data_sets->created_at->format('Y-m-d H:i:s');
        });

        $datasets = new Collection([
            $$water_level_data_sets->map(function(WaterReading $water_level_data_sets) {
                return number_format($water_level_data_sets->reading, 2, '.', '');
            }),
        ]);

        return (new ChartComponentData($labels, $datasets));
    }
}
