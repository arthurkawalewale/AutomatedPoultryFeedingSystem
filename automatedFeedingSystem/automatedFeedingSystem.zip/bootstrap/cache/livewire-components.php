<?php return array (
  'water-level-data-sets' => 'App\\Http\\Livewire\\WaterLevelDataSets',
);