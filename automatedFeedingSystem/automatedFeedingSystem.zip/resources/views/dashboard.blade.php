@extends('skeleton')

@section('body')

    <livewire:dashboard.water-level-data-sets/>

@endsection
